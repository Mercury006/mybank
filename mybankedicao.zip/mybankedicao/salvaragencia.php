<?php
if (isset($_POST["idAgencia"]) && isset($_POST["numero"]) && isset($_POST["nome"]) && isset($_POST["idCidade"])) {
    $idAgencia = $_POST["idAgencia"];
    $numero = $_POST["numero"];
    $nome = $_POST["nome"];
    $idCidade = $_POST["idCidade"];
    
    require_once "classeagencia.php";
    require_once "classecidade.php";
    
    $agencia = new Agencia();
    $cidade = new Cidade();
    
    if ($idAgencia == "") {
        if ($agencia->inserir($numero, $nome, $idCidade)) {
?>
            <script>
                alert("Registro inserido");
                window.location.href = "agencias.php";
            </script>
<?php
        } else {
?>
            <script>
                alert("Erro na operação");
                window.location.href = "agencias.php";
            </script>
<?php
        }
    } else {
        if ($agencia->alterar($idAgencia, $numero, $nome, $idCidade)) {
?>
            <script>
                alert("Alteração realizada");
                window.location.href = "agencias.php";
            </script>
<?php
        } else {
?>
            <script>
                alert("Erro na operação");
                window.location.href = "agencias.php";
            </script>
<?php
        }
    }
}
?>
