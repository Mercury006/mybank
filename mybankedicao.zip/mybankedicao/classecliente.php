<?php 
class Cliente {
    //cliente (IDCLIENTE,NOME,DTNASCIMENTO,IDADE,CPF,DACCPF,IDCIDADE,EMAIL)
    //DEFINIÇÃO DOS ATRIBUTOS

    private $idCliente;
    private $dtNascimento;
    private $nome;
    private $idade;
    private $cpf;
    private $daccpf;
    private $email;
    private $idCidade;

    //implementação getters e setters

    public function getIdCliente(){
        return $this->idCliente;
    }

    public function getNome(){
        return $this->nome;
    }

    public function getDtNascimento(){
        return $this->dtNascimento;
    }

    public function getIdCidade(){
        return $this->idCidade;
    }

    public function getIdade(){
        return $this->idade;
    }

    public function getCpf(){
        return $this->cpf;
    }

    public function getDaccpf(){
        return $this->daccpf;
    }

    public function getEmail(){
        return $this->email;
    }

    public function setIdCliente($valor){
        $this->idCliente = $valor;
    }

    public function setNome($valor){
        $this->nome = $valor;
    }

    public function setDtNascimento($valor){
        $this->dtNascimento = $valor;
    }

    public function setIdCidade($valor){
        $this->idCidade = $valor;
    }

    public function setIdade($valor){
        $this->idade = $valor;
    }

    public function setCpf($valor){
        $this->cpf = $valor;
    }

    public function setDaccpf($valor){
        $this->daccpf = $valor;
    }

    public function setEmail($valor){
        $this->email = $valor;
    }
    //CRUD
    //CREATE READ UPDATE DELETE

    public function inserir($nome, $dtNascimento, $cpf, $daccpf, $email, $idCidade){
        require("conexaobd.php");
        $comando="SELECT inserir_cliente (:nome, :dtNascimento, :cpf, :daccpf, :email, :idCidade);";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":dtNascimento", $dtNascimento);
        $resultado->bindParam(":nome", $nome);
        $resultado->bindParam(":cpf", $cpf);
        $resultado->bindParam(":daccpf", $daccpf);
        $resultado->bindParam(":email", $email);
        $resultado->bindParam(":idCidade", $idCidade);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function alterar($idCliente, $nome, $dtNascimento, $cpf, $daccpf, $email, $idCidade){
        require("conexaobd.php");
        $comando="SELECT alterar_cliente(:idCliente,:nome, :dtNascimento, :cpf, :daccpf, :email, :idCidade);";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idCliente", $idCliente);
        $resultado->bindParam(":dtNascimento", $dtNascimento);
        $resultado->bindParam(":nome", $nome);
        $resultado->bindParam(":cpf", $cpf);
        $resultado->bindParam(":daccpf", $daccpf);
        $resultado->bindParam(":email", $email);
        $resultado->bindParam(":idCidade", $idCidade);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function excluir($idCliente){
        require("conexaobd.php");
        $comando="DELETE FROM cliente WHERE IDCLIENTE=:idCliente;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idCliente", $idCliente);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    } 

    public function consultar($idCliente){
        require("conexaobd.php");
        $comando="SELECT IDCLIENTE, DTNASCIMENTO, NOME, IDADE, CPF, DACCPF, EMAIL, IDCIDADE FROM cliente WHERE IDCLIENTE=:idCliente;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idCliente", $idCliente);
        $resultado->execute();
        foreach($resultado as $registro){
            $this->idCliente = $registro["IDCLIENTE"];
            $this->dtNascimento = $registro["DTNASCIMENTO"];
            $this->nome = $registro["NOME"];
            $this->idade = $registro["IDADE"];
            $this->cpf = $registro["CPF"];
            $this->daccpf = $registro["DACCPF"];
            $this->email = $registro["EMAIL"];
            $this->idCidade = $registro["IDCIDADE"];
        }
        return ($resultado->rowCount() > 0) ? true : false;
    } 

    public function listar(){
        require("conexaobd.php");
        $comando="SELECT IDCLIENTE, DTNASCIMENTO, NOME, IDADE, CPF, DACCPF, EMAIL, IDCIDADE FROM cliente ORDER BY NOME;";
        $resultado = $conexao->prepare($comando);
        $resultado->execute();
        return $resultado;
    }
}