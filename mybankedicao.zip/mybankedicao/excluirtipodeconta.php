<?php
// Verifica se o parâmetro correto foi passado
if (!isset($_GET["idTipoDeConta"])) {
?>
    <script>
        alert("Parâmetro não foi fornecido");
        window.location.href = "tiposdecontas.php";
    </script>
<?php
exit;
}

// Verifica se o id existe
$idTipoDeConta = $_GET["idTipoDeConta"];
require("classeTipoDeConta.php");
$tipoDeConta = new TipoDeConta();

if (!$tipoDeConta->consultar($idTipoDeConta)) {
?>
    <script>
        alert("Tipo de Conta não encontrado");
        window.location.href = "tiposdecontas.php";
    </script>
<?php
}

// Excluir o registro
if ($tipoDeConta->excluir($idTipoDeConta)) {
?>
    <script>
        alert("Operação Realizada");
        window.location.href = "tiposdecontas.php";
    </script>
<?php
} else {
?>
    <script>
        alert("Operação Inválida");
        window.location.href = "tiposdecontas.php";
    </script>
<?php
}
?>
