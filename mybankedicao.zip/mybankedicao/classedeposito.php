<?php
class Deposito {
    private $idDeposito;
    private $dt;
    private $hr;
    private $valor;
    private $idConta;

    public function getIdDeposito() {
        return $this->idDeposito;
    }

    public function getDt() {
        return $this->dt;
    }

    public function getHr() {
        return $this->hr;
    }

    public function getValor() {
        return $this->valor;
    }

    public function getIdConta() {
        return $this->idConta;
    }

    public function setIdDeposito($idDeposito) {
        $this->idDeposito = $idDeposito;
    }

    public function setDt($dt) {
        $this->dt = $dt;
    }

    public function setHr($hr) {
        $this->hr = $hr;
    }

    public function setValor($valor) {
        $this->valor = $valor;
    }

    public function setIdConta($idConta) {
        $this->idConta = $idConta;
    }

    public function inserir($dt, $hr, $valor, $idConta) {
        require("conexaobd.php");
        $conexao->beginTransaction();
        try {
            $comando = "INSERT INTO deposito (DT, HR, VALOR, IDCONTA) VALUES (:dt, :hr, :valor, :idConta);";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":dt", $dt);
            $resultado->bindParam(":hr", $hr);
            $resultado->bindParam(":valor", $valor);
            $resultado->bindParam(":idConta", $idConta);
            $resultado->execute();

            $comando = "UPDATE conta SET SALDO = SALDO + :valor WHERE IDCONTA = :idConta;";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":valor", $valor);
            $resultado->bindParam(":idConta", $idConta);
            $resultado->execute();

            $conexao->commit();
            return ($resultado->rowCount() > 0) ? true : false;
        } catch (Exception $e) {
            $conexao->rollBack();
            return false;
        }
    }

    public function alterar($idDeposito, $dt, $hr, $valor, $idConta) {
        require("conexaobd.php");
        $conexao->beginTransaction();
        try {
            $comando = "UPDATE deposito SET DT=:dt, HR=:hr, VALOR=:valor, IDCONTA=:idConta WHERE IDDEPOSITO=:idDeposito;";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":idDeposito", $idDeposito);
            $resultado->bindParam(":dt", $dt);
            $resultado->bindParam(":hr", $hr);
            $resultado->bindParam(":valor", $valor);
            $resultado->bindParam(":idConta", $idConta);
            $resultado->execute();

            $comando = "UPDATE conta SET SALDO = (SALDO + :novoValor) - (SELECT VALOR FROM deposito WHERE IDDEPOSITO = :idDeposito) WHERE IDCONTA = :idConta;";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":novoValor", $valor);
            $resultado->bindParam(":idDeposito", $idDeposito);
            $resultado->bindParam(":idConta", $idConta);
            $resultado->execute();

            $conexao->commit();
            return ($resultado->rowCount() > 0) ? true : false;
        } catch (Exception $e) {
            $conexao->rollBack();
            return false;
        }
    }

    public function excluir($idDeposito) {
        require("conexaobd.php");
        $conexao->beginTransaction();
        try {
            $comando = "DELETE FROM deposito WHERE IDDEPOSITO=:idDeposito;";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":idDeposito", $idDeposito);
            $resultado->execute();

            $comando = "UPDATE conta SET SALDO = SALDO - (SELECT VALOR FROM deposito WHERE IDDEPOSITO = :idDeposito) WHERE IDCONTA = (SELECT IDCONTA FROM deposito WHERE IDDEPOSITO = :idDeposito);";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":idDeposito", $idDeposito);
            $resultado->execute();

            $conexao->commit();
            return ($resultado->rowCount() > 0) ? true : false;
        } catch (Exception $e) {
            $conexao->rollBack();
            return false;
        }
    }

    public function consultar($idDeposito) {
        require("conexaobd.php");
        $comando = "SELECT IDDEPOSITO, DT, HR, VALOR, IDCONTA FROM deposito WHERE IDDEPOSITO=:idDeposito;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idDeposito", $idDeposito);
        $resultado->execute();
        foreach ($resultado as $registro) {
            $this->idDeposito = $registro["IDDEPOSITO"];
            $this->dt = $registro["DT"];
            $this->hr = $registro["HR"];
            $this->valor = $registro["VALOR"];
            $this->idConta = $registro["IDCONTA"];
        }
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function listar() {
        require("conexaobd.php");
        $comando = "SELECT IDDEPOSITO, DT, HR, VALOR, IDCONTA FROM deposito ORDER BY DT;";
        $resultado = $conexao->prepare($comando);
        $resultado->execute();
        return $resultado;
    }
}
?>
