<?php
class Conta {
    private $idConta;
    private $numero;
    private $idCliente;
    private $idAgencia;
    private $idTipoDeConta;
    private $saldo;

    public function getIdConta() {
        return $this->idConta;
    }

    public function getNumero() {
        return $this->numero;
    }

    public function getIdCliente() {
        return $this->idCliente;
    }

    public function getIdAgencia() {
        return $this->idAgencia;
    }

    public function getIdTipoDeConta() {
        return $this->idTipoDeConta;
    }

    public function getSaldo() {
        return $this->saldo;
    }

    public function setIdConta($idConta) {
        $this->idConta = $idConta;
    }

    public function setNumero($numero) {
        $this->numero = $numero;
    }

    public function setIdCliente($idCliente) {
        $this->idCliente = $idCliente;
    }

    public function setIdAgencia($idAgencia) {
        $this->idAgencia = $idAgencia;
    }

    public function setIdTipoDeConta($idTipoDeConta) {
        $this->idTipoDeConta = $idTipoDeConta;
    }

    public function setSaldo($saldo) {
        $this->saldo = $saldo;
    }

    public function inserir($numero, $idCliente, $idAgencia, $idTipoDeConta, $saldo) {
        require("conexaobd.php");
        $comando = "INSERT INTO conta (NUMERO, IDCLIENTE, IDAGENCIA, IDTIPODECONTA, SALDO) VALUES (:numero, :idCliente, :idAgencia, :idTipoDeConta, :saldo);";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":numero", $numero);
        $resultado->bindParam(":idCliente", $idCliente);
        $resultado->bindParam(":idAgencia", $idAgencia);
        $resultado->bindParam(":idTipoDeConta", $idTipoDeConta);
        $resultado->bindParam(":saldo", $saldo);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function alterar($idConta, $numero, $idCliente, $idAgencia, $idTipoDeConta, $saldo) {
        require("conexaobd.php");
        $comando = "UPDATE conta SET NUMERO=:numero, IDCLIENTE=:idCliente, IDAGENCIA=:idAgencia, IDTIPODECONTA=:idTipoDeConta, SALDO=:saldo WHERE IDCONTA=:idConta;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idConta", $idConta);
        $resultado->bindParam(":numero", $numero);
        $resultado->bindParam(":idCliente", $idCliente);
        $resultado->bindParam(":idAgencia", $idAgencia);
        $resultado->bindParam(":idTipoDeConta", $idTipoDeConta);
        $resultado->bindParam(":saldo", $saldo);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function excluir($idConta) {
        require("conexaobd.php");
        $comando = "DELETE FROM conta WHERE IDCONTA=:idConta;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idConta", $idConta);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function consultar($idConta) {
        require("conexaobd.php");
        $comando = "SELECT IDCONTA, NUMERO, IDCLIENTE, IDAGENCIA, IDTIPODECONTA, SALDO FROM conta WHERE IDCONTA=:idConta;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idConta", $idConta);
        $resultado->execute();
        foreach ($resultado as $registro) {
            $this->idConta = $registro["IDCONTA"];
            $this->numero = $registro["NUMERO"];
            $this->idCliente = $registro["IDCLIENTE"];
            $this->idAgencia = $registro["IDAGENCIA"];
            $this->idTipoDeConta = $registro["IDTIPODECONTA"];
            $this->saldo = $registro["SALDO"];
        }
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function listar() {
        require("conexaobd.php");
        $comando = "SELECT IDCONTA, NUMERO, IDCLIENTE, IDAGENCIA, IDTIPODECONTA, SALDO FROM conta ORDER BY NUMERO;";
        $resultado = $conexao->prepare($comando);
        $resultado->execute();
        return $resultado;
    }
}
