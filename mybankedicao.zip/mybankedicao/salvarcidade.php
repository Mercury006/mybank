<?php
if (isset($_POST["idCidade"]) && (isset($_POST["nome"])) && (isset($_POST["idEstado"]))) {
    $idCidade = $_POST["idCidade"];
    $nome = $_POST["nome"];
    $idEstado = $_POST["idEstado"];
    require "classecidade.php";
    $cidade = new Cidade();
    if ($idCidade == "") {
        if ($cidade->inserir($nome, $idEstado)) {
?>
            <script>
                alert("Registro inserido")
                window.location.href = "cidades.php";
            </script>
        <?php
            //inseriu
        } else {
        ?>
            //erro
            <script>
                alert("Erro na operação")
                window.location.href = "cidades.php";
            </script>
        <?php
        }
    } else {
        if ($cidade->alterar($idCidade, $nome, $idEstado)) {
        ?>
            //alterou
            <script>
                alert("alteração realizada")
                window.location.href = "cidades.php";
            </script>
        <?php

        } else {
        ?>
         //erro
            <script>
                alert("Erro na operação")
                window.location.href = "estados.php";
            </script>
        <?php
                    }
                }
            }

?>