<?php
$idConta = "";
$numero = "";
$idCliente = "";
$idAgencia = "";
$idTipoDeConta = "";
$saldo = "";

require('classeConta.php');
require('classeCliente.php');
require('classeAgencia.php');
require('classeTipoDeConta.php');

$conta = new Conta();
$clienteObj = new Cliente();
$agenciaObj = new Agencia();
$tipoDeContaObj = new TipoDeConta();

$clientes = $clienteObj->listar();
$agencias = $agenciaObj->listar();
$tiposDeConta = $tipoDeContaObj->listar();

if (isset($_GET["idConta"])) {
    $idConta = $_GET["idConta"];
    if ($conta->consultar($idConta)) {
        $numero = $conta->getNumero();
        $idCliente = $conta->getIdCliente();
        $idAgencia = $conta->getIdAgencia();
        $idTipoDeConta = $conta->getIdTipoDeConta();
        $saldo = $conta->getSaldo();
    } else {
        echo "<script>
                alert('Operação Inválida');
                window.location.href = 'contascorrentes.php';
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyBank 1.0</title>
    <link rel="icon" href="logo.svg">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <header class="cabecalho">
        <section class="cabecalho-logo">
            <img class="cabecalho-logo-imagem" src="logo.svg">
            <h1 class="cabecalho-logo-texto">MyBank 1.0</h1>
        </section>
        <section class="cabecalho-menu">
            <nav class="cabecalho-menu-navegacao">
                <a class="cabecalho-menu-navegacao-item" href="index.php">Principal</a>
                <a class="cabecalho-menu-navegacao-item" href="estados.php">Estados</a>
                <a class="cabecalho-menu-navegacao-item" href="cidades.php">Cidades</a>
                <a class="cabecalho-menu-navegacao-item" href="clientes.php">Clientes</a>
                <a class="cabecalho-menu-navegacao-item" href="agencias.php">Agências</a>
                <a class="cabecalho-menu-navegacao-item" href="tiposdecontas.php">Tipos de<br> Contas</a>
                <a class="cabecalho-menu-navegacao-item" href="contascorrentes.php">Contas<br>Correntes</a>
                <a class="cabecalho-menu-navegacao-item" href="tiposdemoviments.php">Tipos de<br>Movimentos</a>
                <a class="cabecalho-menu-navegacao-item" href="depositos.php">Depósitos</a>
                <a class="cabecalho-menu-navegacao-item" href="saques.php">Saques</a>
            </nav>
        </section>
    </header>

    <main class="conteudo-dados">
        <section class="conteudo-dados-titulo">
            <h1 class="conteudo-dados-titulo-texto">
                Conta Corrente
            </h1>
        </section>
        <section>
            <form class="conteudo-dados-formulario" action="salvarconta.php" method="POST">
                <input type="hidden" name="idConta" value="<?php echo $idConta; ?>">
                <label for="numero">Número:</label>
                <input type="text" class="conteudo-dados-formulario-entrada" name="numero" value="<?php echo $numero; ?>" maxlength="10" placeholder="Número da Conta" required>
                <label for="idCliente">Cliente:</label>
                <select name="idCliente" class="conteudo-dados-formulario-entrada" required>
                    <?php foreach ($clientes as $cliente): ?>
                        <option value="<?php echo $cliente['IDCLIENTE']; ?>" <?php echo ($idCliente == $cliente['IDCLIENTE']) ? 'selected' : ''; ?>>
                            <?php echo $cliente['NOME']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <label for="idAgencia">Agência:</label>
                <select name="idAgencia" class="conteudo-dados-formulario-entrada" required>
                    <?php foreach ($agencias as $agencia): ?>
                        <option value="<?php echo $agencia['IDAGENCIA']; ?>" <?php echo ($idAgencia == $agencia['IDAGENCIA']) ? 'selected' : ''; ?>>
                            <?php echo $agencia['NOME']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <label for="idTipoDeConta">Tipo de Conta:</label>
                <select name="idTipoDeConta" class="conteudo-dados-formulario-entrada" required>
                    <?php foreach ($tiposDeConta as $tipoDeConta): ?>
                        <option value="<?php echo $tipoDeConta['IDTIPODECONTA']; ?>" <?php echo ($idTipoDeConta == $tipoDeConta['IDTIPODECONTA']) ? 'selected' : ''; ?>>
                            <?php echo $tipoDeConta['NOME']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <label for="saldo">Saldo:</label>
                <input type="text" class="conteudo-dados-formulario-entrada" name="saldo" value="<?php echo $saldo; ?>" placeholder="Saldo da Conta" required>
                <input type="submit" class="conteudo-dados-formulario-botao" name="botaoSalvar" value="Salvar">
            </form>
        </section>
    </main>

    <footer class="rodape">
        <section class="rodape-autor">
            <p class="rodape-autor-nome">
            Eduardo Felipe Spinelli - Direitos Reservados &reg;
            </p>
        </section>
        <section class="rodape-contato">
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-youtube rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Youtube</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-facebook rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Facebook</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-square-instagram rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Instagram</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-linkedin rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Linkedin</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-square-whatsapp rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Whatsapp</span>
            </a>
        </section>
    </footer>
</body>
</html>
