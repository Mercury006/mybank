<?php
if (isset($_POST["idTipoDeConta"]) && isset($_POST["nome"])) {
    $idTipoDeConta = $_POST["idTipoDeConta"];
    $nome = $_POST["nome"];

    require("classeTipoDeConta.php");
    $tipoDeConta = new TipoDeConta();

    if ($idTipoDeConta == "") {
        if ($tipoDeConta->inserir($nome)) {
?>
            <script>
                alert("Registro inserido");
                window.location.href = "tiposdecontas.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Erro na operação");
                window.location.href = "tiposdecontas.php";
            </script>
        <?php
        }
    } else {
        if ($tipoDeConta->alterar($idTipoDeConta, $nome)) {
        ?>
            <script>
                alert("Alteração realizada");
                window.location.href = "tiposdecontas.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Erro na operação");
                window.location.href = "tiposdecontas.php";
            </script>
        <?php
        }
    }
}
?>
