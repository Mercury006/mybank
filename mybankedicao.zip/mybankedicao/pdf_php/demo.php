<?php

use Dompdf\dompdf;
require_once "dompdf/autoload.inc.php";
$dompdf = new Dompdf();

//$conteudo = "Olá Mundo!!";

// Inicia o buffer de saída
ob_start();
// Inclui o arquivo tela.php e captura sua saída
include "exemplo.php";
// Obtém o conteúdo do buffer de saída e armazena em uma variável
$conteudo = ob_get_clean();


$dompdf->loadHtml($conteudo);
$dompdf->setPaper("A4","portrait"); // portrait ou landscape
$dompdf->render();
$dompdf->stream();


