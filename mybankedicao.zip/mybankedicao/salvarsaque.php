<?php
if (isset($_POST["idSaque"]) && isset($_POST["dt"]) && isset($_POST["hr"]) && isset($_POST["valor"]) && isset($_POST["idConta"])) {
    $idSaque = $_POST["idSaque"];
    $dt = $_POST["dt"];
    $hr = $_POST["hr"];
    $valor = $_POST["valor"];
    $idConta = $_POST["idConta"];

    require("classeSaque.php");
    $saque = new Saque();

    if ($idSaque == "") {
        if ($saque->inserir($dt, $hr, $valor, $idConta)) {
?>
            <script>
                alert("Registro inserido");
                window.location.href = "saques.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Erro na operação");
                window.location.href = "saques.php";
            </script>
        <?php
        }
    } else {
        if ($saque->alterar($idSaque, $dt, $hr, $valor, $idConta)) {
        ?>
            <script>
                alert("Alteração realizada");
                window.location.href = "saques.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Erro na operação");
                window.location.href = "saques.php";
            </script>
        <?php
        }
    }
}
?>
