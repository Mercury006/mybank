<?php
if (isset($_POST["idCliente"]) && (isset($_POST["nome"])) && (isset($_POST["dtNascimento"])) && (isset($_POST["cpf"])) && (isset($_POST["daccpf"])) && (isset($_POST["email"])) && (isset($_POST["idCidade"]))) {
    $idCliente = $_POST["idCliente"];
    $nome = $_POST["nome"];
    $dtNascimento = $_POST["dtNascimento"];
    $cpf = $_POST["cpf"];
    $daccpf = $_POST["daccpf"];
    $email = $_POST["email"];
    $idCidade = $_POST["idCidade"];

    require "classecliente.php";
    $cliente = new Cliente();
    if ($idCliente == "") {
        if ($cliente->inserir($nome, $dtNascimento, $cpf, $daccpf, $email, $idCidade)) {
?>
            <script>
                alert("Registro inserido")
                window.location.href = "clientes.php";
            </script>
        <?php
            //inseriu
        } else {
        ?>
            //erro
            <script>
                alert("Erro na operação")
                window.location.href = "clientes.php";
            </script>
        <?php
        }
    } else {
        if ($cliente->alterar($idCliente, $nome, $dtNascimento, $cpf, $daccpf, $email, $idCidade)) {
        ?>
            //alterou
            <script>
                alert("alteração realizada")
                window.location.href = "clientes.php";
            </script>
        <?php

        } else {
        ?>
         //erro
            <script>
                alert("Erro na operação")
                window.location.href = "clientes.php";
            </script>
        <?php
                    }
                }
            }

?>