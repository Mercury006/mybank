<?php
//Verifica se o parâmetro correto foi passado
if (!isset($_GET["idCliente"])) {
?>
    <script>
        alert("Parâmetro não foi fornecido");
        window.location.href = "clientes.php";
    </script>
<?php
exit;
}
//Verifica se o id existe
$idCliente = $_GET["idCliente"];
require("classecliente.php");
$cliente = new Cliente();

if (!$cliente->consultar($idCliente)) {
?>
    <script>
        alert("Cliente não encontrado");
        window.location.href = "clientes.php";
    </script>
<?php
}
//Excluir o registro
if ($cliente->excluir($idCliente)) {
?>
    <script>
        alert("Operação Realizada");
        window.location.href = "clientes.php";
    </script>
<?php
} else {
?>
    <script>
        alert("Operação Inválida");
        window.location.href = "clientes.php";
    </script>
<?php
}
?>