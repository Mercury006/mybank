<?php
// Verifica se o parâmetro correto foi passado
if (!isset($_GET["idConta"])) {
?>
    <script>
        alert("Parâmetro não foi fornecido");
        window.location.href = "contascorrentes.php";
    </script>
<?php
exit;
}

// Verifica se o id existe
$idConta = $_GET["idConta"];
require("classeConta.php");
$conta = new Conta();

if (!$conta->consultar($idConta)) {
?>
    <script>
        alert("Conta não encontrada");
        window.location.href = "contascorrentes.php";
    </script>
<?php
}

// Excluir o registro
if ($conta->excluir($idConta)) {
?>
    <script>
        alert("Operação Realizada");
        window.location.href = "contascorrentes.php";
    </script>
<?php
} else {
?>
    <script>
        alert("Operação Inválida");
        window.location.href = "contascorrentes.php";
    </script>
<?php
}
?>
