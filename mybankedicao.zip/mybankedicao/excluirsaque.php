<?php
// Verifica se o parâmetro correto foi passado
if (!isset($_GET["idSaque"])) {
?>
    <script>
        alert("Parâmetro não foi fornecido");
        window.location.href = "saques.php";
    </script>
<?php
exit;
}

// Verifica se o id existe
$idSaque = $_GET["idSaque"];
require("classeSaque.php");
$saque = new Saque();

if (!$saque->consultar($idSaque)) {
?>
    <script>
        alert("Saque não encontrado");
        window.location.href = "saques.php";
    </script>
<?php
}

// Excluir o registro
if ($saque->excluir($idSaque)) {
?>
    <script>
        alert("Operação Realizada");
        window.location.href = "saques.php";
    </script>
<?php
} else {
?>
    <script>
        alert("Operação Inválida");
        window.location.href = "saques.php";
    </script>
<?php
}
?>
