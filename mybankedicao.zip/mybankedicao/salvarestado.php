<?php
if (isset($_POST["idEstado"]) && (isset($_POST["nome"])) && (isset($_POST["sigla"]))) {
    $idEstado = $_POST["idEstado"];
    $nome = $_POST["nome"];
    $sigla = $_POST["sigla"];
    require "classeestado.php";
    $estado = new Estado();
    if ($idEstado == "") {
        if ($estado->inserir($sigla, $nome)) {
?>
            <script>
                alert("Registro inserido")
                window.location.href = "estados.php";
            </script>
        <?php
            //inseriu
        } else {
        ?>
            //erro
            <script>
                alert("Erro na operação")
                window.location.href = "estados.php";
            </script>
        <?php
        }
    } else {
        if ($estado->alterar($idEstado, $sigla, $nome)) {
        ?>
            //alterou
            <script>
                alert("alteração realizada")
                window.location.href = "estados.php";
            </script>
        <?php

        } else {
        ?>
         //erro
            <script>
                alert("Erro na operação")
                window.location.href = "estados.php";
            </script>
        <?php
                    }
                }
            }

?>