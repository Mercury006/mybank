<?php
class TipoDeConta {
    private $idTipoDeConta;
    private $nome;

    public function getIdTipoDeConta() {
        return $this->idTipoDeConta;
    }

    public function getNome() {
        return $this->nome;
    }

    public function setIdTipoDeConta($idTipoDeConta) {
        $this->idTipoDeConta = $idTipoDeConta;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function inserir($nome) {
        require("conexaobd.php");
        $comando = "INSERT INTO tipodeconta (NOME) VALUES (:nome);";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":nome", $nome);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function alterar($idTipoDeConta, $nome) {
        require("conexaobd.php");
        $comando = "UPDATE tipodeconta SET NOME=:nome WHERE IDTIPODECONTA=:idTipoDeConta;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idTipoDeConta", $idTipoDeConta);
        $resultado->bindParam(":nome", $nome);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function excluir($idTipoDeConta) {
        require("conexaobd.php");
        $comando = "DELETE FROM tipodeconta WHERE IDTIPODECONTA=:idTipoDeConta;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idTipoDeConta", $idTipoDeConta);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function consultar($idTipoDeConta) {
        require("conexaobd.php");
        $comando = "SELECT IDTIPODECONTA, NOME FROM tipodeconta WHERE IDTIPODECONTA=:idTipoDeConta;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idTipoDeConta", $idTipoDeConta);
        $resultado->execute();
        foreach ($resultado as $registro) {
            $this->idTipoDeConta = $registro["IDTIPODECONTA"];
            $this->nome = $registro["NOME"];
        }
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function listar() {
        require("conexaobd.php");
        $comando = "SELECT IDTIPODECONTA, NOME FROM tipodeconta ORDER BY NOME;";
        $resultado = $conexao->prepare($comando);
        $resultado->execute();
        return $resultado;
    }
}