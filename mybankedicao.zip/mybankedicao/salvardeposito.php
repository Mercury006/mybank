<?php
if (isset($_POST["idDeposito"]) && isset($_POST["dt"]) && isset($_POST["hr"]) && isset($_POST["valor"]) && isset($_POST["idConta"])) {
    $idDeposito = $_POST["idDeposito"];
    $dt = $_POST["dt"];
    $hr = $_POST["hr"];
    $valor = $_POST["valor"];
    $idConta = $_POST["idConta"];

    require("classeDeposito.php");
    $deposito = new Deposito();

    if ($idDeposito == "") {
        if ($deposito->inserir($dt, $hr, $valor, $idConta)) {
?>
            <script>
                alert("Registro inserido");
                window.location.href = "depositos.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Erro na operação");
                window.location.href = "depositos.php";
            </script>
        <?php
        }
    } else {
        if ($deposito->alterar($idDeposito, $dt, $hr, $valor, $idConta)) {
        ?>
            <script>
                alert("Alteração realizada");
                window.location.href = "depositos.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Erro na operação");
                window.location.href = "depositos.php";
            </script>
        <?php
        }
    }
}
?>
