<?php
//Verifica se o parâmetro correto foi passado
if (!isset($_GET["idCidade"])) {
?>
    <script>
        alert("Parâmetro não foi fornecido");
        window.location.href = "cidades.php";
    </script>
<?php
exit;
}
//Verifica se o id existe
$idCidade = $_GET["idCidade"];
require("classecidade.php");
$cidade = new Cidade();

if (!$cidade->consultar($idCidade)) {
?>
    <script>
        alert("Cidade não encontrado");
        window.location.href = "cidades.php";
    </script>
<?php
}
//Excluir o registro
if ($cidade->excluir($idCidade)) {
?>
    <script>
        alert("Operação Realizada");
        window.location.href = "cidades.php";
    </script>
<?php
} else {
?>
    <script>
        alert("Operação Inválida");
        window.location.href = "cidades.php";
    </script>
<?php
}
?>