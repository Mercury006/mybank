<?php
$idDeposito = "";
$dt = "";
$hr = "";
$valor = "";
$idConta = "";

require('classeDeposito.php');
require('classeConta.php');

$deposito = new Deposito();
$contaObj = new Conta();

$contas = $contaObj->listar();

if (isset($_GET["idDeposito"])) {
    $idDeposito = $_GET["idDeposito"];
    if ($deposito->consultar($idDeposito)) {
        $dt = $deposito->getDt();
        $hr = $deposito->getHr();
        $valor = $deposito->getValor();
        $idConta = $deposito->getIdConta();
    } else {
        echo "<script>
                alert('Operação Inválida');
                window.location.href = 'depositos.php';
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyBank 1.0</title>
    <link rel="icon" href="logo.svg">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>
<body>
    <header class="cabecalho">
        <section class="cabecalho-logo">
            <img class="cabecalho-logo-imagem" src="logo.svg">
            <h1 class="cabecalho-logo-texto">MyBank 1.0</h1>
        </section>
        <section class="cabecalho-menu">
            <nav class="cabecalho-menu-navegacao">
                <a class="cabecalho-menu-navegacao-item" href="index.php">Principal</a>
                <a class="cabecalho-menu-navegacao-item" href="estados.php">Estados</a>
                <a class="cabecalho-menu-navegacao-item" href="cidades.php">Cidades</a>
                <a class="cabecalho-menu-navegacao-item" href="clientes.php">Clientes</a>
                <a class="cabecalho-menu-navegacao-item" href="agencias.php">Agências</a>
                <a class="cabecalho-menu-navegacao-item" href="tiposdecontas.php">Tipos de<br> Contas</a>
                <a class="cabecalho-menu-navegacao-item" href="contascorrentes.php">Contas<br>Correntes</a>
                <a class="cabecalho-menu-navegacao-item" href="tiposdemoviments.php">Tipos de<br>Movimentos</a>
                <a class="cabecalho-menu-navegacao-item" href="depositos.php">Depósitos</a>
                <a class="cabecalho-menu-navegacao-item" href="saques.php">Saques</a>
            </nav>
        </section>
    </header>

    <main class="conteudo-dados">
        <section class="conteudo-dados-titulo">
            <h1 class="conteudo-dados-titulo-texto">
                Depósito
            </h1>
        </section>
        <section>
            <form class="conteudo-dados-formulario" action="salvardeposito.php" method="POST">
                <input type="hidden" name="idDeposito" value="<?php echo $idDeposito; ?>">
                <label for="dt">Data:</label>
                <input type="date" class="conteudo-dados-formulario-entrada" name="dt" value="<?php echo $dt; ?>" required>
                <label for="hr">Hora:</label>
                <input type="time" class="conteudo-dados-formulario-entrada" name="hr" value="<?php echo $hr; ?>" required>
                <label for="valor">Valor:</label>
                <input type="number" step="0.01" class="conteudo-dados-formulario-entrada" name="valor" value="<?php echo $valor; ?>" required>
                <label for="idConta">Conta:</label>
                <select name="idConta" class="conteudo-dados-formulario-entrada" required>
                    <?php foreach ($contas as $conta): ?>
                        <option value="<?php echo $conta['IDCONTA']; ?>" <?php echo ($idConta == $conta['IDCONTA']) ? 'selected' : ''; ?>>
                            <?php echo $conta['NUMERO']; ?>
                        </option>
                    <?php endforeach; ?>
                </select>
                <input type="submit" class="conteudo-dados-formulario-botao" name="botaoSalvar" value="Salvar">
            </form>
        </section>
    </main>

    <footer class="rodape">
        <section class="rodape-autor">
            <p class="rodape-autor-nome">
            Eduardo Felipe Spinelli - Direitos Reservados &reg;
            </p>
        </section>
        <section class="rodape-contato">
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-youtube rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Youtube</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-facebook rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Facebook</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-square-instagram rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Instagram</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-linkedin rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Linkedin</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-square-whatsapp rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Whatsapp</span>
            </a>
        </section>
    </footer>
</body>
</html>
