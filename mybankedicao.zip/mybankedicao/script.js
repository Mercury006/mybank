var menuSobre = document.querySelector("#menu-sobre");
var menuLocalizacao = document.querySelector("#menu-localizacao")

var dialogSobre = document.querySelector("#dialog-sobre");
var dialogLocalizacao = document.querySelector("dialog-localizacao");

var botaoDialogSobreFechar = document.querySelector("#dialog-dialog-sobre-fechar");
var botaoDialogSobreLocalizacaoFechar = document.querySelector("#botao-dialog-localizacao-fechar");

menuSobre.onclick = function(){
    dialogSobre.showModal();
}

menuLocalizacao.onclick = function(){
    dialogLocalizacao.showModal();
}

botaoDialogSobreFechar.onclick = function(){
    dialogSobre.close();
}

botaoDialogSobreLocalizacaoFechar.onclick = function(){
    dialogLocalizacao.close();
}