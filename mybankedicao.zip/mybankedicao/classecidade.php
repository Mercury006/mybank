<?php 
class Cidade {
    //estado (IDCIDADE,NOME,CLIENTES,AGENCIAS,IDESTADO)
    //DEFINIÇÃO DOS ATRIBUTOS

    private $idCidade;
    private $nome;
    private $clientes;
    private $agencias;
    private $idEstado;

    //implementação getters e setters

    public function getIdCidade(){
        return $this->idCidade;
    }
    public function getNome(){
        return $this->nome;
    }
    public function getClientes(){
        return $this->clientes;
    }
    public function getAgencias(){
        return $this->agencias;
    }
    public function getIdEstado(){
        return $this->idEstado;
    }

    public function setIdCidade($valor){
        $this->idCidade = $valor;
    }
    public function setNome($valor){
        $this->nome = $valor;
    }
    public function setClientes($valor){
        $this->clientes = $valor;
    }
    public function setAgencias($valor){
        $this->agencias = $valor;
    }
    public function setIdEstado($valor){
        $this->idEstado = $valor;
    }

    //CRUD
    //CREATE READ UPDATE DELETE

    public function inserir($nome, $idEstado){
        require("conexaobd.php");
        $comando="INSERT INTO cidade (NOME,IDESTADO) VALUES (:nome, :idEstado);";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":nome", $nome);
        $resultado->bindParam(":idEstado", $idEstado);
        $resultado->execute();
        return($resultado->rowCount() > 0) ? true : false;
    }

    public function alterar($idCidade, $nome, $idEstado){
        require("conexaobd.php");
        $comando="UPDATE cidade SET NOME=:nome, IDESTADO=:idEstado WHERE IDCIDADE=:idCidade;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idCidade", $idCidade);
        $resultado->bindParam(":nome", $nome);
        $resultado->bindParam(":idEstado", $idEstado);
        $resultado->execute();
        return($resultado->rowCount() > 0) ? true : false;
    }

    public function excluir($idCidade){
        require("conexaobd.php");
        $comando="DELETE FROM cidade WHERE IDCIDADE=:idCidade;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idCidade", $idCidade);
        $resultado->execute();
        return($resultado->rowCount() > 0) ? true : false;
    } 

    public function consultar($idCidade){
        require("conexaobd.php");
        $comando="SELECT IDCIDADE,NOME,CLIENTES,AGENCIAS,IDESTADO FROM cidade WHERE IDCIDADE=:idCidade;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idCidade", $idCidade);
        $resultado->execute();
        foreach($resultado as $registro){
            $this->idCidade = $registro["IDCIDADE"];
            $this->nome = $registro["NOME"];
            $this->clientes = $registro["CLIENTES"];
            $this->agencias = $registro["AGENCIAS"];
            $this->idEstado = $registro["IDESTADO"];
        }
        return($resultado->rowCount() > 0) ? true : false;
    } 

    public function listar(){
        require("conexaobd.php");
        $comando="SELECT IDCIDADE,NOME,CLIENTES,AGENCIAS,IDESTADO FROM cidade ORDER BY NOME;";
        $resultado = $conexao->prepare($comando);
        $resultado->execute();
        return $resultado;
    }
}
?>
