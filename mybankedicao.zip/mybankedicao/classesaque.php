<?php
class Saque {
    private $idSaque;
    private $dt;
    private $hr;
    private $valor;
    private $idConta;

    public function getIdSaque() {
        return $this->idSaque;
    }

    public function getDt() {
        return $this->dt;
    }

    public function getHr() {
        return $this->hr;
    }

    public function getValor() {
        return $this->valor;
    }

    public function getIdConta() {
        return $this->idConta;
    }

    public function setIdSaque($idSaque) {
        $this->idSaque = $idSaque;
    }

    public function setDt($dt) {
        $this->dt = $dt;
    }

    public function setHr($hr) {
        $this->hr = $hr;
    }

    public function setValor($valor) {
        $this->valor = $valor;
    }

    public function setIdConta($idConta) {
        $this->idConta = $idConta;
    }

    public function inserir($dt, $hr, $valor, $idConta) {
        require("conexaobd.php");
        $conexao->beginTransaction();
        try {
            $comando = "INSERT INTO saque (DT, HR, VALOR, IDCONTA) VALUES (:dt, :hr, :valor, :idConta);";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":dt", $dt);
            $resultado->bindParam(":hr", $hr);
            $resultado->bindParam(":valor", $valor);
            $resultado->bindParam(":idConta", $idConta);
            $resultado->execute();

            $comando = "UPDATE conta SET SALDO = SALDO - :valor WHERE IDCONTA = :idConta;";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":valor", $valor);
            $resultado->bindParam(":idConta", $idConta);
            $resultado->execute();

            $conexao->commit();
            return ($resultado->rowCount() > 0) ? true : false;
        } catch (Exception $e) {
            $conexao->rollBack();
            return false;
        }
    }

    public function alterar($idSaque, $dt, $hr, $valor, $idConta) {
        require("conexaobd.php");
        $conexao->beginTransaction();
        try {
            $comando = "UPDATE saque SET DT=:dt, HR=:hr, VALOR=:valor, IDCONTA=:idConta WHERE IDSAQUE=:idSaque;";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":idSaque", $idSaque);
            $resultado->bindParam(":dt", $dt);
            $resultado->bindParam(":hr", $hr);
            $resultado->bindParam(":valor", $valor);
            $resultado->bindParam(":idConta", $idConta);
            $resultado->execute();

            $comando = "UPDATE conta SET SALDO = (SALDO - :novoValor) + (SELECT VALOR FROM saque WHERE IDSAQUE = :idSaque) WHERE IDCONTA = :idConta;";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":novoValor", $valor);
            $resultado->bindParam(":idSaque", $idSaque);
            $resultado->bindParam(":idConta", $idConta);
            $resultado->execute();

            $conexao->commit();
            return ($resultado->rowCount() > 0) ? true : false;
        } catch (Exception $e) {
            $conexao->rollBack();
            return false;
        }
    }

    public function excluir($idSaque) {
        require("conexaobd.php");
        $conexao->beginTransaction();
        try {
            $comando = "DELETE FROM saque WHERE IDSAQUE=:idSaque;";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":idSaque", $idSaque);
            $resultado->execute();

            $comando = "UPDATE conta SET SALDO = SALDO + (SELECT VALOR FROM saque WHERE IDSAQUE = :idSaque) WHERE IDCONTA = (SELECT IDCONTA FROM saque WHERE IDSAQUE = :idSaque);";
            $resultado = $conexao->prepare($comando);
            $resultado->bindParam(":idSaque", $idSaque);
            $resultado->execute();

            $conexao->commit();
            return ($resultado->rowCount() > 0) ? true : false;
        } catch (Exception $e) {
            $conexao->rollBack();
            return false;
        }
    }

    public function consultar($idSaque) {
        require("conexaobd.php");
        $comando = "SELECT IDSAQUE, DT, HR, VALOR, IDCONTA FROM saque WHERE IDSAQUE=:idSaque;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idSaque", $idSaque);
        $resultado->execute();
        foreach ($resultado as $registro) {
            $this->idSaque = $registro["IDSAQUE"];
            $this->dt = $registro["DT"];
            $this->hr = $registro["HR"];
            $this->valor = $registro["VALOR"];
            $this->idConta = $registro["IDCONTA"];
        }
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function listar() {
        require("conexaobd.php");
        $comando = "SELECT IDSAQUE, DT, HR, VALOR, IDCONTA FROM saque ORDER BY DT;";
        $resultado = $conexao->prepare($comando);
        $resultado->execute();
        return $resultado;
    }
}
?>
