<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyBank 1.0</title>
    <link rel="icon" href="logo.svg">
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>

    <header class="cabecalho">
        <section class="cabecalho-logo">
            <img class="cabecalho-logo-imagem" src="logo.svg">
            <h1 class="cabecalho-logo-texto">MyBank 1.0</h1>
        </section>
        <section class="cabecalho-menu">
            <nav class="cabecalho-menu-navegacao">
                <a class="cabecalho-menu-navegacao-item" href="index.php">Principal</a>
                <a class="cabecalho-menu-navegacao-item" href="estados.php">Estados</a>
                <a class="cabecalho-menu-navegacao-item" href="cidades.php">Cidades</a>
                <a class="cabecalho-menu-navegacao-item" href="clientes.php">Clientes</a>
                <a class="cabecalho-menu-navegacao-item" href="agencias.php">Agências</a>
                <a class="cabecalho-menu-navegacao-item" href="tiposdecontas.php">Tipos de<br> Contas</a>
                <a class="cabecalho-menu-navegacao-item" href="contascorrentes.php">Contas<br>Correntes</a>
                <a class="cabecalho-menu-navegacao-item" href="tiposdemoviments.php">Tipos de<br>Movimentos</a>
                <a class="cabecalho-menu-navegacao-item" href="contascorrentes.php">Depósitos</a>
                <a class="cabecalho-menu-navegacao-item" href="contascorrentes.php">Saques</a>
                <a class="cabecalho-menu-navegacao-item" id="menu-sobre" href="#">Sobre</a>
                <a class="cabecalho-menu-navegacao-item" href="#" id="menu-localizacao">Localização</a>
            </nav>
        </section>
    </header>
    <main class="conteudo">
        <section class="conteudo-texto">
            <section class="conteudo-texto-superior">
                <h1 class="conteudo-texto-superior-h1">
                    MyBank 1.0
                </h1>
                <h2 class="conteudo-texto-superior-h2">
                    Transformando sonhos em realidade!
                </h2>
            </section>

            <section class="conteudo-texto-inferior">
                <h3 class="conteudo-texto-inferior-h3">
                    Aqui você tem...
                </h3>
                <ul class="conteudo-texto-inferior-servicos">
                    <li class="conteudo-texto-inferior-servicos-item">Abertura de Conta Corrente Online</li>
                    <li class="conteudo-texto-inferior-servicos-item">Gerenciamento de Contas</li>
                    <li class="conteudo-texto-inferior-servicos-item">Empréstimos e Financiamentos</li>
                    <li class="conteudo-texto-inferior-servicos-item">Investimentos</li>
                    <li class="conteudo-texto-inferior-servicos-item">Cartões de Crédito e Débito</li>
                </ul>
            </section>
        </section>

        <section class="conteudo-ilustracao">
            <img src="gerentes.png" alt="Imagem do Médico" class="conteudo-ilustracao-imagem">
        </section>
    </main>

    <footer class="rodape">
        <section class="rodape-autor">
            <p class="rodape-autor-nome">
                Eduardo Felipe Spinelli - Direitos Reservados &reg;
            </p>
        </section>
        <section class="rodape-contato">
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-youtube rodape-contato-link-icone"></i>
                <spam class="rodape-contato-icone-legenda">Youtube</spam>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-facebook rodape-contato-link-icone"></i>
                <spam class="rodape-contato-icone-legenda">Facebook</spam>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-square-instagram rodape-contato-link-icone"></i>
                <spam class="rodape-contato-icone-legenda">Instagram</spam>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-linkedin rodape-contato-link-icone"></i>
                <spam class="rodape-contato-icone-legenda">Linkedin</spam>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fa-brands fa-square-whatsapp rodape-contato-link-icone"></i>
                <spam class="rodape-contato-icone-legenda">Whatsapp</spam>
            </a>
        </section>
    </footer>

    <dialog id="dialog-sobre">
        <h1>Sobre</h1>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ex explicabo, ea tempore ipsam cupiditate eos 
           voluptate aspernatur quas incidunt minus libero dolore magni. Delectus, et eius nulla fugiat ullam nam.</p>
        <button id="botao-dialog-sobre-fechar">Fechar</button>
    </dialog>

    <dialog id="dialog-localizacao">
        <h1>Localização</h1>
        <?php
        // Endereço IP do cliente
        $ip_cliente = $_SERVER['REMOTE_ADDR'];

        echo "IP: $ip_cliente";
        echo "<br><br>";

        // URL da API do Geoplugin
        $url = "http://www.geoplugin.net/json.gp?ip={$ip_cliente}";

        // Realiza a solicitação para obter os dados de localização
        $response = file_get_contents($url);

        // Decodifica a resposta JSON em um array associativo
        $dados_localizacao = json_decode($response, true);

        // Verifica se a resposta foi obtida com sucesso
        if ($dados_localizacao && isset($dados_localizacao['geoplugin_countryName'])) {
            // Exibe os dados de localização
            echo "País: " . $dados_localizacao['geoplugin_countryName'] . "<br><br>";
            echo "Cidade: " . $dados_localizacao['geoplugin_city'] . "<br><br>";
            echo "Região: " . $dados_localizacao['geoplugin_regionName'] . "<br><br>";
            echo "Latitude: " . $dados_localizacao['geoplugin_latitude'] . "<br><br>";
            echo "Longitude: " . $dados_localizacao['geoplugin_longitude'] . "<br><br>";
        } else {
            echo "Não foi possível obter os dados de localização.";
        }
        ?>
        <br><br><br>
        <button class="botao-fechar-dialog" id="botao-dialog-localizacao-fechar">Fechar</button>
    </dialog>

    <script>
        document.getElementById('menu-sobre').addEventListener('click', function () {
            document.getElementById('dialog-sobre').showModal();
        });

        document.getElementById('botao-dialog-sobre-fechar').addEventListener('click', function () {
            document.getElementById('dialog-sobre').close();
        });

        document.getElementById('menu-localizacao').addEventListener('click', function () {
            document.getElementById('dialog-localizacao').showModal();
        });

        document.getElementById('botao-dialog-localizacao-fechar').addEventListener('click', function () {
            document.getElementById('dialog-localizacao').close();
        });
    </script>
</body>

</html>
