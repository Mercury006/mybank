<?php
// Verifica se o parâmetro correto foi passado
if (!isset($_GET["idDeposito"])) {
?>
    <script>
        alert("Parâmetro não foi fornecido");
        window.location.href = "depositos.php";
    </script>
<?php
exit;
}

// Verifica se o id existe
$idDeposito = $_GET["idDeposito"];
require("classeDeposito.php");
$deposito = new Deposito();

if (!$deposito->consultar($idDeposito)) {
?>
    <script>
        alert("Depósito não encontrado");
        window.location.href = "depositos.php";
    </script>
<?php
}

// Excluir o registro
if ($deposito->excluir($idDeposito)) {
?>
    <script>
        alert("Operação Realizada");
        window.location.href = "depositos.php";
    </script>
<?php
} else {
?>
    <script>
        alert("Operação Inválida");
        window.location.href = "depositos.php";
    </script>
<?php
}
?>
