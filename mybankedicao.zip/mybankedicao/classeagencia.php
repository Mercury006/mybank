<?php

class Agencia {
    // Definição dos atributos
    private $idAgencia;
    private $numero;
    private $nome;
    private $idCidade;

    // Implementação dos getters e setters
    public function getIdAgencia() {
        return $this->idAgencia;
    }

    public function getNumero() {
        return $this->numero;
    }

    public function getNome() {
        return $this->nome;
    }

    public function getIdCidade() {
        return $this->idCidade;
    }

    public function setIdAgencia($idAgencia) {
        $this->idAgencia = $idAgencia;
    }

    public function setNumero($numero) {
        $this->numero = $numero;
    }

    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function setIdCidade($idCidade) {
        $this->idCidade = $idCidade;
    }

    // Métodos CRUD

    public function inserir($numero, $nome, $idCidade) {
        require("conexaobd.php");
        $comando = "INSERT INTO agencia (NUMERO, NOME, IDCIDADE) VALUES (:numero, :nome, :idCidade);";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":numero", $numero);
        $resultado->bindParam(":nome", $nome);
        $resultado->bindParam(":idCidade", $idCidade);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function alterar($idAgencia, $numero, $nome, $idCidade) {
        require("conexaobd.php");
        $comando = "UPDATE agencia SET NUMERO=:numero, NOME=:nome, IDCIDADE=:idCidade WHERE IDAGENCIA=:idAgencia;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idAgencia", $idAgencia);
        $resultado->bindParam(":numero", $numero);
        $resultado->bindParam(":nome", $nome);
        $resultado->bindParam(":idCidade", $idCidade);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function excluir($idAgencia) {
        require("conexaobd.php");
        $comando = "DELETE FROM agencia WHERE IDAGENCIA=:idAgencia;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idAgencia", $idAgencia);
        $resultado->execute();
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function consultar($idAgencia) {
        require("conexaobd.php");
        $comando = "SELECT IDAGENCIA, NUMERO, NOME, IDCIDADE FROM agencia WHERE IDAGENCIA=:idAgencia;";
        $resultado = $conexao->prepare($comando);
        $resultado->bindParam(":idAgencia", $idAgencia);
        $resultado->execute();
        foreach ($resultado as $registro) {
            $this->idAgencia = $registro["IDAGENCIA"];
            $this->numero = $registro["NUMERO"];
            $this->nome = $registro["NOME"];
            $this->idCidade = $registro["IDCIDADE"];
        }
        return ($resultado->rowCount() > 0) ? true : false;
    }

    public function listar() {
        require("conexaobd.php");
        $comando = "SELECT IDAGENCIA, NUMERO, NOME, IDCIDADE FROM agencia ORDER BY NOME;";
        $resultado = $conexao->prepare($comando);
        $resultado->execute();
        return $resultado;
    }
}

?>
