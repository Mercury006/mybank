<?php
if (isset($_POST["idConta"]) && isset($_POST["numero"]) && isset($_POST["idCliente"]) && isset($_POST["idAgencia"]) && isset($_POST["idTipoDeConta"]) && isset($_POST["saldo"])) {
    $idConta = $_POST["idConta"];
    $numero = $_POST["numero"];
    $idCliente = $_POST["idCliente"];
    $idAgencia = $_POST["idAgencia"];
    $idTipoDeConta = $_POST["idTipoDeConta"];
    $saldo = $_POST["saldo"];

    require("classeConta.php");
    $conta = new Conta();

    if ($idConta == "") {
        if ($conta->inserir($numero, $idCliente, $idAgencia, $idTipoDeConta, $saldo)) {
?>
            <script>
                alert("Registro inserido");
                window.location.href = "contascorrentes.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Erro na operação");
                window.location.href = "contascorrentes.php";
            </script>
        <?php
        }
    } else {
        if ($conta->alterar($idConta, $numero, $idCliente, $idAgencia, $idTipoDeConta, $saldo)) {
        ?>
            <script>
                alert("Alteração realizada");
                window.location.href = "contascorrentes.php";
            </script>
        <?php
        } else {
        ?>
            <script>
                alert("Erro na operação");
                window.location.href = "contascorrentes.php";
            </script>
        <?php
        }
    }
}
?>
