<?php
//Verifica se o parâmetro correto foi passado
if (!isset($_GET["idEstado"])) {
?>
    <script>
        alert("Parâmetro não foi fornecido");
        window.location.href = "estados.php";
    </script>
<?php
exit;
}
//Verifica se o id existe
$idEstado = $_GET["idEstado"];
require("classeestado.php");
$estado = new Estado();

if (!$estado->consultar($idEstado)) {
?>
    <script>
        alert("Estado não encontrado");
        window.location.href = "estados.php";
    </script>
<?php
}
//Excluir o registro
if ($estado->excluir($idEstado)) {
?>
    <script>
        alert("Operação Realizada");
        window.location.href = "estados.php";
    </script>
<?php
} else {
?>
    <script>
        alert("Operação Inválida");
        window.location.href = "estados.php";
    </script>
<?php
}
?>