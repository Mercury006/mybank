<?php

$idAgencia = "";
$numero = "";
$nome = "";
$idCidade = "";

if (isset($_GET["idAgencia"])) {
    require_once("classeagencia.php");
    $idAgencia = $_GET["idAgencia"];
    $agencia = new Agencia();
    if ($agencia->consultar($idAgencia)) {
        $numero = $agencia->getNumero();
        $nome = $agencia->getNome();
        $idCidade = $agencia->getIdCidade();
    } else {
?>
        <script>
            alert("Operação Inválida");
            window.location.href = "agencias.php";
        </script>
<?php
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>MyBank 1.0 - Agências</title>
    <link rel="icon" href="logo.svg">
    <link rel="stylesheet" type="text/css" href="estilo.css">
    <link rel="stylesheet" type="text/css" href="style.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css" integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
</head>

<body>

    <header class="cabecalho">
        <section class="cabecalho-logo">
            <img class="cabecalho-logo-imagem" src="logo.svg">
            <h1 class="cabecalho-logo-texto">MyBank 1.0</h1>
        </section>
        <section class="cabecalho-menu">
            <nav class="cabecalho-menu-navegacao">
                <a class="cabecalho-menu-navegacao-item" href="index.php">Principal</a>
                <a class="cabecalho-menu-navegacao-item" href="estados.php">Estados</a>
                <a class="cabecalho-menu-navegacao-item" href="cidades.php">Cidades</a>
                <a class="cabecalho-menu-navegacao-item" href="clientes.php">Clientes</a>
                <a class="cabecalho-menu-navegacao-item" href="agencias.php">Agências</a>
                <a class="cabecalho-menu-navegacao-item" href="tiposdecontas.php">Tipos de Contas</a>
                <a class="cabecalho-menu-navegacao-item" href="contascorrentes.php">Contas Correntes</a>
                <a class="cabecalho-menu-navegacao-item" href="tiposdemoviments.php">Tipos de Movimentos</a>
                <a class="cabecalho-menu-navegacao-item" href="contascorrentes.php">Depósitos</a>
                <a class="cabecalho-menu-navegacao-item" href="contascorrentes.php">Saques</a>
            </nav>
        </section>
    </header>
    <main class="conteudo-dados">
        <section class="conteudo-dados-titulo">
            <h1 class="conteudo-dados-titulo-texto">
                Agência
            </h1>
        </section>
        <section>
            <form class="conteudo-dados-formulario" action="salvaragencia.php" method="POST">
                <input type="hidden" name="idAgencia" value="<?php echo $idAgencia; ?>">
                <label for="numero">Número</label>
                <input type="text" class="conteudo-dados-formulario-entrada" name="numero" value="<?php echo $numero; ?>" maxlength="10" placeholder="Número da Agência (0000-x)" required>
                <label for="nome">Nome</label>
                <input type="text" class="conteudo-dados-formulario-entrada" name="nome" value="<?php echo $nome; ?>" maxlength="100" placeholder="Nome da Agência" required>
                <label for="idCidade">Cidade</label>
                <select id="idCidade" name="idCidade" class="conteudo-dados-formulario-entrada" required>
                    <option value="">Selecione a Cidade</option>
                    <?php
                    require_once("classecidade.php");
                    $cidade = new Cidade();
                    $cidades = $cidade->listar();
                    foreach ($cidades as $registro) {
                        $selecionado = ($idCidade == $registro["IDCIDADE"]) ? "selected" : "";
                        ?>
                        <option value="<?php echo $registro["IDCIDADE"]; ?>" <?php echo $selecionado; ?>>
                            <?php echo $registro["NOME"]; ?>
                        </option>
                        <?php
                    }
                    ?>
                </select>
                <input type="submit" class="conteudo-dados-formulario-botao" name="botaoSalvar" value="Salvar">
            </form>
        </section>

    </main>

    <footer class="rodape">
        <section class="rodape-autor">
            <p class="rodape-autor-nome">
                Eduardo Felipe Spinelli - Direitos Reservados &reg;
            </p>
        </section>
        <section class="rodape-contato">
            <a href="#" class="rodape-contato-link">
                <i class="fab fa-youtube rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Youtube</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fab fa-facebook rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Facebook</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fab fa-instagram-square rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Instagram</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fab fa-linkedin rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Linkedin</span>
            </a>
            <a href="#" class="rodape-contato-link">
                <i class="fab fa-whatsapp-square rodape-contato-link-icone"></i>
                <span class="rodape-contato-icone-legenda">Whatsapp</span>
            </a>
        </section>
    </footer>

    <script>
        function excluir(id) {
            if (confirm("Tem certeza que deseja excluir o registro?")) {
                if (confirm("Realmente quer excluir o registro?\nNão é possível reverter essa operação!")) {
                    var link = "excluiragencia.php?idAgencia=" + id;
                    window.location.href = link;
                }
            }
        }
    </script>
</body>

</html>
